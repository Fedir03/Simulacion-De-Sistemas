package ar.edu.itba.sds.tp3;

import ar.edu.itba.sds.tp3.engine.*;
import ar.edu.itba.sds.tp3.engine.obstacles.ObstacleGenerators;
import ar.edu.itba.sds.tp3.io.StageFile;
import ar.edu.itba.sds.tp3.models.Obstacle;
import ar.edu.itba.sds.tp3.models.Particle;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public final class Main {
    private Main() { }
    public static void main(String[] args) {
        try { execute(args); }
        catch (IllegalArgumentException | IOException e) {
            System.err.println("Error: " + e.getMessage()); System.exit(1);
        }
    }
    public static void execute(String[] args) throws IOException {
        if (args.length == 0 || args[0].equals("--help")) {
            System.out.println("""
                    generate [--n 100] [--seed 42] [--out archivo.txt] [--obstacles-out config.txt]
                             [--obstacle-algorithm random|none|single|funnel|semicircle|posts|lattice|ellipse]
                               random:     [--obstacle-count 2] [--obstacle-radius 0.05] [--obstacle-seed <seed>]
                               single:     [--obstacle-x L/2] [--obstacle-y W/2] [--obstacle-radius 0.1]
                               funnel:     [--obstacle-funnel-length 0.3] [--obstacle-edge-radius <radio de la frontera>]
                                           [--obstacle-max-radius ∞] [--obstacle-grid 0.001]
                               semicircle: [--obstacle-free-radius 0.36] [--obstacle-center-offset 0] [--obstacle-goals right|both]
                                           [--obstacle-edge-radius <radio de la frontera>] [--obstacle-max-radius ∞] [--obstacle-grid 0.001]
                               posts:      [--obstacle-radius 0.05]
                               lattice:    [--obstacle-spacing 0.1] [--obstacle-radius r]
                               ellipse:    [--obstacle-focus-x 0.3] [--obstacle-edge-radius r]
                                           [--obstacle-focus-shape none|disc|line|lens] [--obstacle-focus-size 0.1]
                                           [--obstacle-lens-width 0.03] [--obstacle-max-radius ∞] [--obstacle-grid 0.001]
                             [--obstacles archivo.txt (con --obstacle-algorithm, el algoritmo agrega obstáculos a los del archivo)]
                             [--length 1.2] [--width 0.68] [--goal-width 0.2]
                             [--radius 0.0175] [--mass 0.025] [--speed 1.0]
                    simulate --input archivo.txt [--time 30] [--every 100] [--out archivo.txt]
                             [--events-out <salida>_events.txt | none] [--until time | t90]
                             --every k escribe el estado completo cada k eventos; --events-out guarda
                             una línea por evento (t, tipo, participantes, gol), sin el estado
                             --until t90 termina al llegar al 90 % de partículas usadas (--time es el máximo)
                    Salidas predeterminadas: TP3/generated/initial.txt, TP3/generated/simulation.txt
                    y TP3/generated/simulation_events.txt
                    """);
            return;
        }
        Set<String> allowed = switch (args[0]) {
            case "generate" -> Set.of("n", "seed", "obstacles", "out", "obstacles-out", "length", "width", "goal-width", "radius", "mass", "speed",
                    "obstacle-algorithm", "obstacle-count", "obstacle-radius", "obstacle-seed", "obstacle-x", "obstacle-y",
                    "obstacle-funnel-length", "obstacle-edge-radius", "obstacle-free-radius", "obstacle-center-offset", "obstacle-goals", "obstacle-max-radius", "obstacle-grid", "obstacle-spacing",
                    "obstacle-focus-x", "obstacle-focus-shape", "obstacle-focus-size", "obstacle-lens-width");
            case "simulate" -> Set.of("input", "time", "every", "out", "events-out", "until");
            default -> throw new IllegalArgumentException("Comando desconocido: " + args[0]);
        };
        Map<String, String> options = new HashMap<>();
        for (int i = 1; i < args.length; i += 2) {
            if (!args[i].startsWith("--") || i + 1 >= args.length) throw new IllegalArgumentException("Se esperaba --opción valor");
            String key = args[i].substring(2);
            if (!allowed.contains(key) || options.put(key, args[i + 1]) != null) throw new IllegalArgumentException("Opción inválida o repetida: " + key);
        }
        if (args[0].equals("generate")) {
            SimulationConfig c = new SimulationConfig(value(options, "length", "1.2"), value(options, "width", "0.68"),
                    value(options, "goal-width", "0.2"), value(options, "radius", "0.0175"), value(options, "mass", "0.025"), value(options, "speed", "1"));
            long seed = Long.parseLong(options.getOrDefault("seed", "42"));
            boolean generatorOptions = options.keySet().stream().anyMatch(key -> key.startsWith("obstacle-"));
            boolean fromFile = options.containsKey("obstacles"), withAlgorithm = !fromFile || options.containsKey("obstacle-algorithm");
            if (fromFile && generatorOptions && !withAlgorithm)
                throw new IllegalArgumentException("Para combinar --obstacles con opciones --obstacle-*, indicar --obstacle-algorithm");
            String algorithm = options.getOrDefault("obstacle-algorithm", "random");
            Map<String, String> params = new HashMap<>();
            options.forEach((key, v) -> { if (key.startsWith("obstacle-") && !key.equals("obstacle-algorithm")) params.put(key.substring(9), v); });
            // Los obstáculos del archivo son la base; el algoritmo, si se indica, agrega obstáculos respetándolos.
            List<Obstacle> obstacles = new ArrayList<>(fromFile ? StageFile.readObstacles(Path.of(options.get("obstacles"))) : List.of());
            if (withAlgorithm) obstacles.addAll(ObstacleGenerators.create(algorithm, params)
                    .generate(c, Long.parseLong(options.getOrDefault("obstacle-seed", Long.toString(seed))), List.copyOf(obstacles)));
            var stage = StageGeneration.generate(c, Integer.parseInt(options.getOrDefault("n", "100")),
                    seed, obstacles);
            Path out = output(options, "initial.txt");
            StageFile.write(out, stage);
            System.out.println("Condición inicial: " + out + " | K=" + obstacles.size());
            if (options.containsKey("obstacles-out")) {
                Path config = Path.of(options.get("obstacles-out"));
                StageFile.writeObstacles(config, obstacles);
                System.out.println("Obstáculos: " + config);
            }
        } else {
            if (!options.containsKey("input")) throw new IllegalArgumentException("Falta --input");
            Path input = Path.of(options.get("input")), out = output(options, "simulation.txt");
            if (input.toAbsolutePath().normalize().equals(out.toAbsolutePath().normalize())
                    || Files.exists(out) && Files.isSameFile(input, out)) throw new IllegalArgumentException("Entrada y salida deben ser distintas");
            double endTime = value(options, "time", "30");
            int every = Integer.parseInt(options.getOrDefault("every", "100"));
            if (!Double.isFinite(endTime) || endTime < 0 || every <= 0) throw new IllegalArgumentException("Tiempo o frecuencia inválidos");
            // Registro de todos los eventos: por defecto <salida>_events.txt; "none" lo desactiva.
            String eventsOption = options.getOrDefault("events-out", out.getFileName().toString().replaceFirst("(\\.txt)?$", "_events.txt"));
            Path eventsOut = eventsOption.equals("none") ? null
                    : options.containsKey("events-out") ? Path.of(eventsOption) : out.resolveSibling(eventsOption);
            if (eventsOut != null && (eventsOut.toAbsolutePath().normalize().equals(out.toAbsolutePath().normalize())
                    || eventsOut.toAbsolutePath().normalize().equals(input.toAbsolutePath().normalize())))
                throw new IllegalArgumentException("--events-out debe ser distinto de la entrada y la salida");
            String until = options.getOrDefault("until", "time");
            if (!until.equals("time") && !until.equals("t90")) throw new IllegalArgumentException("--until debe ser time o t90");
            var stage = StageFile.read(input);
            try (BufferedWriter w = StageFile.writer(out);
                 BufferedWriter log = eventsOut == null ? null : StageFile.writer(eventsOut)) {
                StageFile.header(w, stage);
                if (log != null) StageFile.eventHeader(log);
                // Goles y t90 en vivo, con el mismo criterio de t90 que CollisionSimulator.
                int n = stage.particles().size(), target = (int) Math.ceil(0.9 * n);
                int[] goals = {(int) stage.particles().stream().filter(Particle::used).count()};
                CollisionSimulator.EventSink fileLog = log == null ? CollisionSimulator.EventSink.NONE
                        : (t, i, type, a, b, goal) -> StageFile.event(log, t, i, type, a, b, goal);
                long start = System.nanoTime();
                var result = new CollisionSimulator(stage).run(endTime, every,
                        (t, e, g, p) -> StageFile.frame(w, t, e, g, p),
                        (t, i, type, a, b, goal) -> {
                            fileLog.event(t, i, type, a, b, goal);
                            if (!goal) return;
                            System.out.printf(Locale.ROOT, "gol %d/%d t=%.4f s (partícula %d)%n", ++goals[0], n, t, a);
                            if (goals[0] == target) System.out.printf(Locale.ROOT, "t90 alcanzado: t=%.4f s (%d/%d)%n", t, goals[0], n);
                        },
                        until.equals("t90"));
                // Tiempo de ejecución del ciclo de eventos, escritura incluida; excluye arranque de la JVM y lectura.
                double runtime = (System.nanoTime() - start) / 1e9;
                w.write("# tf=" + result.time() + " outputEvery=" + every + " events=" + result.events() + " Ng=" + result.goals()
                        + " t90=" + result.t90() + " runtime=" + runtime);
                w.newLine();
                if (eventsOut != null) System.out.println("Eventos: " + eventsOut);
                System.out.println("Trayectoria: " + out + " | eventos=" + result.events() + " goles=" + result.goals()
                        + " t90=" + result.t90() + " runtime=" + runtime + "s");
            }
        }
    }
    private static double value(Map<String, String> options, String key, String fallback) {
        return Double.parseDouble(options.getOrDefault(key, fallback));
    }
    private static Path output(Map<String, String> options, String name) {
        if (options.containsKey("out")) return Path.of(options.get("out"));
        // Independiente del cwd: ubica el módulo desde target/classes o desde su JAR.
        try {
            Path code = Path.of(Main.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            Path base = Files.isDirectory(code) ? code : code.getParent();
            while (base != null) {
                if (Files.isDirectory(base.resolve("enunciado")) && Files.exists(base.resolve("pom.xml")))
                    return base.resolve("generated").resolve(name);
                base = base.getParent();
            }
        } catch (java.net.URISyntaxException e) { throw new IllegalStateException(e); }
        throw new IllegalArgumentException("No se pudo ubicar TP3; indicar --out");
    }
}
