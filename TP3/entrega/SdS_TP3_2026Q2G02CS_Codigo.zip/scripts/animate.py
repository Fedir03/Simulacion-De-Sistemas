#!/usr/bin/env python3
"""Exporta los frames guardados de una trayectoria TP3 a MP4 o GIF, en orden."""
import argparse
import dataclasses
import math
import multiprocessing
from pathlib import Path
import subprocess
import sys
import tempfile

from simulation_io import parse_simulation


ARROW_REACH = 1.8  # largo del pico medido desde el centro, en radios: asoma 0.8 r del borde


def arrow_components(particles):
    """Dirección de cada velocidad (no su módulo), escalada a ARROW_REACH radios."""
    u, v = [], []
    for p in particles:
        speed = math.hypot(p[5], p[6])
        reach = ARROW_REACH * p[3] / speed if speed > 0 else 0.0
        u.append(p[5] * reach)
        v.append(p[6] * reach)
    return u, v


def render_animation(data, output, *, fps=30, speed=1.0, dpi=120, progress=True, arrows=False, hold=0.0, final=True):
    """Con final, el último cuadro muestra t90 y se repite durante hold segundos de video.
    final=False es para los tramos intermedios del render en paralelo."""
    if not all(math.isfinite(value) and value > 0 for value in (fps, dpi, speed, fps * speed)):
        raise ValueError('fps, dpi y speed deben ser positivos y finitos')
    if not (math.isfinite(hold) and hold >= 0):
        raise ValueError('hold debe ser un número no negativo')
    output = Path(output)
    if output.suffix.lower() not in ('.mp4', '.gif'):
        raise ValueError('--out debe terminar en .mp4 o .gif')
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        from matplotlib.animation import FFMpegWriter, PillowWriter
        from matplotlib.patches import Circle
        from matplotlib.lines import Line2D
    except ImportError as exc:
        raise RuntimeError('Instalá las dependencias: python3 -m pip install -r TP3/requirements.txt') from exc
    if output.suffix.lower() == '.mp4':
        if not FFMpegWriter.isAvailable():
            raise RuntimeError('MP4 requiere FFmpeg en PATH; también podés usar --out animacion.gif')
        writer = FFMpegWriter(fps=fps * speed, codec='libx264', extra_args=['-pix_fmt', 'yuv420p'])
    else:
        writer = PillowWriter(fps=fps * speed)
    count = len(data.frames)
    output.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.set(xlim=(0, data.length), ylim=(0, data.width), xlabel='x [m]', ylabel='y [m]')
    ax.set_aspect('equal')
    ax.set_facecolor('#f1f5f9')
    for x, y, radius in data.obstacles:
        ax.add_patch(Circle((x, y), radius, color='#475569'))
    for x in (0, data.length):
        ax.plot([x, x], [(data.width - data.goal_width) / 2,
                        (data.width + data.goal_width) / 2],
                color='#16a34a', linewidth=6, clip_on=False, zorder=4)
    circles = []
    for pid, x, y, radius, color, *_ in data.frames[0].particles:
        circle = Circle((x, y), radius, facecolor=color, edgecolor='white', linewidth=0.4, zorder=3)
        ax.add_patch(circle)
        circles.append(circle)
    # Pico de dirección: flecha desde el centro dibujada debajo del disco, así solo asoma la punta.
    quiver = None
    if arrows:
        first = data.frames[0].particles
        width = 0.3 * first[0][3]
        quiver = ax.quiver([p[1] for p in first], [p[2] for p in first], *arrow_components(first),
                           angles='xy', scale_units='xy', scale=1, units='xy', width=width,
                           headwidth=4, headlength=3, headaxislength=2.7, color='black', zorder=2)
    # «Obstáculo» solo si la mesa tiene obstáculos.
    entries = [('blue', 'Fresca'), ('red', 'Usada')] + ([('#475569', 'Obstáculo')] if data.obstacles else []) \
        + [('#16a34a', 'Arco')]
    ax.legend(handles=[Line2D([], [], marker='o', linestyle='', color=color, label=label) for color, label in entries],
              loc='upper center', bbox_to_anchor=(0.5, -0.16), ncol=len(entries), fontsize=16, markerscale=1.6)
    title = ax.set_title('', loc='left', fontsize=15)
    t90_label = ax.set_title('', loc='right', color='#16a34a', fontweight='bold', fontsize=15)
    fig.subplots_adjust(bottom=0.24, top=0.88)
    try:
        with writer.saving(fig, str(output), dpi):
            for i, frame in enumerate(data.frames):
                for circle, p in zip(circles, frame.particles):
                    circle.center = (p[1], p[2])
                    circle.set_radius(p[3])
                    circle.set_facecolor(p[4])
                if quiver is not None:
                    quiver.set_offsets([(p[1], p[2]) for p in frame.particles])
                    quiver.set_UVC(*arrow_components(frame.particles))
                title.set_text(f't = {frame.time:.3f} s · Partículas convertidas: {frame.goals}')
                if final and i == count - 1:
                    t90_label.set_text(f't90 = {data.t90:.3f} s' if math.isfinite(data.t90) else 't90 no alcanzado')
                writer.grab_frame()
                if progress and (i % max(1, count // 100) == 0 or i == count - 1):
                    print(f'\rGenerando animación: {i + 1}/{count} cuadros', end='', flush=True)
            # Pausa final sobre el último estado para que se lea t90.
            for _ in range(round(hold * fps * speed) if final else 0):
                writer.grab_frame()
        if progress:
            print()
    finally:
        plt.close(fig)


def _render_part(task):
    data, output, fps, speed, dpi, arrows, hold, final = task
    render_animation(data, output, fps=fps, speed=speed, dpi=dpi, progress=False, arrows=arrows, hold=hold, final=final)
    return output


def render_parallel(data, output, *, jobs, fps=30, speed=1.0, dpi=120, arrows=False, hold=0.0):
    """Renderiza tramos contiguos de frames en paralelo y los concatena sin recodificar.
    El video tiene exactamente los mismos cuadros, en el mismo orden, que con un solo proceso."""
    output = Path(output)
    jobs = min(jobs, len(data.frames))
    if jobs <= 1 or output.suffix.lower() != '.mp4':
        return render_animation(data, output, fps=fps, speed=speed, dpi=dpi, arrows=arrows, hold=hold)
    bounds = [len(data.frames) * k // jobs for k in range(jobs + 1)]
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='animate_', dir=output.parent) as tmp:
        # Solo el último tramo muestra t90 y agrega la pausa final.
        tasks = [(dataclasses.replace(data, frames=data.frames[a:b]), Path(tmp) / f'part_{k:03d}.mp4', fps, speed, dpi, arrows,
                  hold, k == jobs - 1)
                 for k, (a, b) in enumerate(zip(bounds, bounds[1:]))]
        with multiprocessing.get_context('fork').Pool(jobs) as pool:
            for done, _ in enumerate(pool.imap_unordered(_render_part, tasks), 1):
                print(f'\rGenerando animación: {done}/{jobs} tramos de {len(data.frames)} cuadros', end='', flush=True)
        print()
        listing = Path(tmp) / 'parts.txt'
        listing.write_text(''.join(f"file '{task[1].name}'\n" for task in tasks), encoding='utf-8')
        subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-f', 'concat', '-safe', '0', '-i', str(listing),
                        '-c', 'copy', str(output)], check=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path, help='salida .txt del motor TP3')
    parser.add_argument('--out', type=Path, help='salida .mp4 o .gif; por defecto, junto al TXT')
    parser.add_argument('--fps', type=int, default=30, help='cuadros por segundo (30)')
    parser.add_argument('--speed', type=float, default=1.0,
                        help='multiplicador de FPS: 1 normal, 2 doble, 0.5 mitad (no tiempo real)')
    parser.add_argument('--dpi', type=int, default=120, help='resolución (120)')
    parser.add_argument('--jobs', type=int, default=1,
                        help='procesos para MP4: renderiza tramos en paralelo y los concatena (1)')
    parser.add_argument('--arrows', action='store_true',
                        help='dibuja un pico en la dirección de la velocidad de cada partícula')
    parser.add_argument('--hold', type=float, default=2.0,
                        help='segundos de video que se sostiene el último cuadro mostrando t90 (2)')
    args = parser.parse_args(argv)
    output = args.out or args.input.with_suffix('.mp4')
    try:
        if output.resolve() == args.input.resolve():
            raise ValueError('entrada y salida deben ser distintas')
        data = parse_simulation(args.input)
        if args.jobs < 1:
            raise ValueError('--jobs debe ser positivo')
        render_parallel(data, output, jobs=args.jobs, fps=args.fps, speed=args.speed, dpi=args.dpi,
                        arrows=args.arrows, hold=args.hold)
    except (OSError, ValueError, RuntimeError, subprocess.CalledProcessError) as exc:
        print(f'Error: {exc}', file=sys.stderr)
        return 1
    print(f'Animación guardada en {output.resolve()}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
